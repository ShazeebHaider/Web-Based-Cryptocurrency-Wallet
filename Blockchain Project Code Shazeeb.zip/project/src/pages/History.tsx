import React from 'react';
import TransactionList from '../components/TransactionList';
import { useAuth } from '../context/AuthContext';

const mockTransactions = [
  {
    id: '1',
    type: 'receive',
    amount: 0.1234,
    currency: 'BTC',
    address: '0x1234567890abcdef1234567890abcdef12345678',
    timestamp: '2024-03-15 14:30',
    status: 'completed',
  },
  {
    id: '2',
    type: 'send',
    amount: 0.5678,
    currency: 'ETH',
    address: '0xabcdef1234567890abcdef1234567890abcdef12',
    timestamp: '2024-03-15 12:15',
    status: 'pending',
  },
  {
    id: '3',
    type: 'receive',
    amount: 1.2345,
    currency: 'BTC',
    address: '0x2468135790abcdef1234567890abcdef12345678',
    timestamp: '2024-03-14 09:45',
    status: 'completed',
  },
] as const;

export default function History() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-500">Please login to view your transaction history</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Transaction History</h1>
        <p className="text-gray-500 dark:text-gray-400">View all your past transactions</p>
      </div>

      <TransactionList transactions={mockTransactions} />
    </div>
  );
}