import React, { useState } from 'react';
import { ArrowUpRight, ArrowDownLeft, QrCode, Shield } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import CurrencyCard from '../components/CurrencyCard';
import TransactionList from '../components/TransactionList';
import TransactionModal from '../components/modals/TransactionModal';

const currencies = [
  {
    name: 'Bitcoin',
    symbol: 'BTC',
    icon: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=64&h=64&fit=crop&crop=faces',
  },
  {
    name: 'Ethereum',
    symbol: 'ETH',
    icon: 'https://images.unsplash.com/photo-1622790698141-94e30457ef82?w=64&h=64&fit=crop&crop=faces',
  },
];

const recentTransactions = [
  {
    id: '1',
    type: 'receive',
    amount: 0.1234,
    currency: 'BTC',
    address: '0x1234567890abcdef1234567890abcdef12345678',
    timestamp: '2024-03-15 14:30',
    status: 'completed',
  },
  {
    id: '2',
    type: 'send',
    amount: 0.5678,
    currency: 'ETH',
    address: '0xabcdef1234567890abcdef1234567890abcdef12',
    timestamp: '2024-03-15 12:15',
    status: 'pending',
  },
] as const;

export default function Dashboard() {
  const { user } = useAuth();
  const [showSendModal, setShowSendModal] = useState(false);
  const [showReceiveModal, setShowReceiveModal] = useState(false);

  const quickActions = [
    { icon: ArrowUpRight, label: 'Send', color: 'bg-blue-500', onClick: () => setShowSendModal(true) },
    { icon: ArrowDownLeft, label: 'Receive', color: 'bg-green-500', onClick: () => setShowReceiveModal(true) },
    { icon: QrCode, label: 'Scan QR', color: 'bg-purple-500', onClick: () => setShowReceiveModal(true) },
    { icon: Shield, label: 'Security', color: 'bg-orange-500', onClick: () => alert('Security settings coming soon!') },
  ];

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-500">Please login to view your dashboard</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Welcome back, {user.username}!
        </h1>
        <p className="text-gray-500 dark:text-gray-400">Here's your wallet overview</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        {quickActions.map((action) => (
          <button
            key={action.label}
            onClick={action.onClick}
            className="p-4 rounded-xl bg-white dark:bg-gray-800 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className={`${action.color} w-12 h-12 rounded-full flex items-center justify-center mb-3`}>
              <action.icon className="h-6 w-6 text-white" />
            </div>
            <span className="text-sm font-medium text-gray-900 dark:text-white">{action.label}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {currencies.map((currency) => (
          <CurrencyCard
            key={currency.symbol}
            {...currency}
            balance={user.balances[currency.symbol as keyof typeof user.balances]}
            value={currency.symbol === 'BTC' ? 45000 * user.balances.BTC : 2800 * user.balances.ETH}
            change={currency.symbol === 'BTC' ? 2.34 : -1.23}
          />
        ))}
      </div>

      <TransactionList transactions={recentTransactions} />

      <TransactionModal
        isOpen={showSendModal}
        onClose={() => setShowSendModal(false)}
        type="send"
      />
      <TransactionModal
        isOpen={showReceiveModal}
        onClose={() => setShowReceiveModal(false)}
        type="receive"
      />
    </div>
  );
}