import React from 'react';
import { Wallet, ArrowUpRight, ArrowDownLeft, Shield, Key } from 'lucide-react';

export default function Guide() {
  const sections = [
    {
      title: 'Getting Started',
      icon: Wallet,
      steps: [
        'Create an account by clicking "Register" in the top right',
        'Verify your email address',
        'Set up two-factor authentication for extra security',
        'Add funds to your wallet through bank transfer or crypto deposit'
      ]
    },
    {
      title: 'Sending Crypto',
      icon: ArrowUpRight,
      steps: [
        'Click "Send" from the dashboard',
        'Select the cryptocurrency you want to send',
        'Enter the recipient\'s wallet address',
        'Specify the amount and review transaction fees',
        'Confirm the transaction with your 2FA code'
      ]
    },
    {
      title: 'Receiving Crypto',
      icon: ArrowDownLeft,
      steps: [
        'Click "Receive" from the dashboard',
        'Select which cryptocurrency you want to receive',
        'Copy your wallet address or share the QR code',
        'Wait for the network to confirm the transaction'
      ]
    },
    {
      title: 'Security Best Practices',
      icon: Shield,
      steps: [
        'Never share your private keys or recovery phrase',
        'Enable two-factor authentication',
        'Use a strong, unique password',
        'Regularly check your transaction history',
        'Be cautious of phishing attempts'
      ]
    },
    {
      title: 'Recovery Options',
      icon: Key,
      steps: [
        'Store your recovery phrase in a safe place',
        'Keep backup codes for 2FA',
        'Set up emergency contact information',
        'Test recovery process periodically'
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">
        User Guide
      </h1>
      
      <div className="space-y-8">
        {sections.map((section) => (
          <div key={section.title} className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
            <div className="flex items-center space-x-3 mb-4">
              <section.icon className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                {section.title}
              </h2>
            </div>
            <ol className="list-decimal list-inside space-y-2 text-gray-700 dark:text-gray-300">
              {section.steps.map((step, index) => (
                <li key={index} className="pl-2">{step}</li>
              ))}
            </ol>
          </div>
        ))}
      </div>
    </div>
  );
}