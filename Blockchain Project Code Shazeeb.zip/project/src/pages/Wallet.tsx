import React, { useState } from 'react';
import { ArrowUpRight, ArrowDownLeft, QrCode } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import TransactionModal from '../components/modals/TransactionModal';
import CurrencyCard from '../components/CurrencyCard';

const currencies = [
  {
    name: 'Bitcoin',
    symbol: 'BTC',
    icon: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=64&h=64&fit=crop&crop=faces',
  },
  {
    name: 'Ethereum',
    symbol: 'ETH',
    icon: 'https://images.unsplash.com/photo-1622790698141-94e30457ef82?w=64&h=64&fit=crop&crop=faces',
  },
];

export default function Wallet() {
  const { user } = useAuth();
  const [showSendModal, setShowSendModal] = useState(false);
  const [showReceiveModal, setShowReceiveModal] = useState(false);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-500">Please login to view your wallet</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">My Wallet</h1>
        <p className="text-gray-500 dark:text-gray-400">Manage your cryptocurrencies</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <button
          onClick={() => setShowSendModal(true)}
          className="flex items-center justify-center space-x-2 p-4 rounded-xl bg-blue-500 text-white hover:bg-blue-600 transition-colors"
        >
          <ArrowUpRight className="h-5 w-5" />
          <span>Send</span>
        </button>
        <button
          onClick={() => setShowReceiveModal(true)}
          className="flex items-center justify-center space-x-2 p-4 rounded-xl bg-green-500 text-white hover:bg-green-600 transition-colors"
        >
          <ArrowDownLeft className="h-5 w-5" />
          <span>Receive</span>
        </button>
        <button
          onClick={() => setShowReceiveModal(true)}
          className="flex items-center justify-center space-x-2 p-4 rounded-xl bg-purple-500 text-white hover:bg-purple-600 transition-colors"
        >
          <QrCode className="h-5 w-5" />
          <span>Scan QR</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {currencies.map((currency) => (
          <CurrencyCard
            key={currency.symbol}
            {...currency}
            balance={user.balances[currency.symbol as keyof typeof user.balances]}
            value={currency.symbol === 'BTC' ? 45000 * user.balances.BTC : 2800 * user.balances.ETH}
            change={currency.symbol === 'BTC' ? 2.34 : -1.23}
          />
        ))}
      </div>

      <TransactionModal
        isOpen={showSendModal}
        onClose={() => setShowSendModal(false)}
        type="send"
      />
      <TransactionModal
        isOpen={showReceiveModal}
        onClose={() => setShowReceiveModal(false)}
        type="receive"
      />
    </div>
  );
}