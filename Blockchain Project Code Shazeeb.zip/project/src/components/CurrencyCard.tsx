import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface CurrencyCardProps {
  name: string;
  symbol: string;
  balance: number;
  value: number;
  change: number;
  icon: string;
}

export default function CurrencyCard({ name, symbol, balance, value, change, icon }: CurrencyCardProps) {
  const isPositive = change >= 0;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <img src={icon} alt={name} className="w-10 h-10 rounded-full" />
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-white">{name}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">{symbol}</p>
          </div>
        </div>
        <div className={`flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
          {isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
          <span className="ml-1 text-sm">{change}%</span>
        </div>
      </div>
      <div className="space-y-1">
        <p className="text-2xl font-bold text-gray-900 dark:text-white">
          {balance.toFixed(6)} {symbol}
        </p>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          ≈ ${value.toLocaleString()}
        </p>
      </div>
    </div>
  );
}