import React, { useState } from 'react';
import { X } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useAuth } from '../../context/AuthContext';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'send' | 'receive';
}

export default function TransactionModal({ isOpen, onClose, type }: TransactionModalProps) {
  const [amount, setAmount] = useState('');
  const [address, setAddress] = useState('');
  const [currency, setCurrency] = useState('BTC');
  const [error, setError] = useState('');
  const { user, updateBalance } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (type === 'send') {
      const success = updateBalance(currency as 'BTC' | 'ETH', Number(amount));
      if (!success) {
        setError('Insufficient balance for this transaction');
        return;
      }
    }

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            {type === 'send' ? 'Send Crypto' : 'Receive Crypto'}
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>
        {error && (
          <div className="mb-4 p-2 bg-red-100 text-red-700 rounded">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="currency" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Currency
            </label>
            <select
              id="currency"
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="input-primary mt-1"
            >
              <option value="BTC">Bitcoin (BTC) - Balance: {user?.balances.BTC}</option>
              <option value="ETH">Ethereum (ETH) - Balance: {user?.balances.ETH}</option>
            </select>
          </div>
          <div>
            <label htmlFor="amount" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Amount
            </label>
            <input
              type="number"
              id="amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="input-primary mt-1"
              step="0.00000001"
              required
            />
          </div>
          <div>
            <label htmlFor="address" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              {type === 'send' ? 'Recipient Address' : 'Your Address'}
            </label>
            <input
              type="text"
              id="address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="input-primary mt-1"
              required
            />
          </div>

          {type === 'receive' && address && (
            <div className="flex justify-center p-4 bg-white rounded-lg">
              <QRCodeSVG
                value={`${currency}:${address}?amount=${amount}`}
                size={200}
                level="H"
                includeMargin
              />
            </div>
          )}

          <button type="submit" className="btn-primary w-full">
            {type === 'send' ? 'Send' : 'Generate QR Code'}
          </button>
        </form>
      </div>
    </div>
  );
}