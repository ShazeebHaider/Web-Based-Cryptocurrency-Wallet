import React, { useState } from 'react';
import { Bell, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import ProfileModal from './modals/ProfileModal';
import LoginModal from './modals/LoginModal';
import RegisterModal from './modals/RegisterModal';

export default function Header() {
  const { user } = useAuth();
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  return (
    <>
      <header className="bg-white dark:bg-gray-900 shadow-sm fixed top-0 right-0 left-0 z-30 lg:left-64">
        <div className="mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex-1" />
            <div className="flex items-center space-x-4">
              {user ? (
                <>
                  <button className="p-2 text-gray-600 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400 relative">
                    <Bell className="h-6 w-6" />
                    <span className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full" />
                  </button>
                  <div className="relative">
                    <button
                      onClick={() => setShowProfileModal(true)}
                      className="flex items-center space-x-3 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
                    >
                      <div className="h-8 w-8 rounded-full bg-indigo-600 flex items-center justify-center">
                        <User className="h-5 w-5 text-white" />
                      </div>
                      <span className="hidden sm:block text-sm font-medium text-gray-700 dark:text-gray-200">
                        {user.username}
                      </span>
                    </button>
                  </div>
                </>
              ) : (
                <div className="space-x-2">
                  <button
                    onClick={() => setShowRegisterModal(true)}
                    className="btn-secondary"
                  >
                    Register
                  </button>
                  <button
                    onClick={() => setShowLoginModal(true)}
                    className="btn-primary"
                  >
                    Login
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <ProfileModal isOpen={showProfileModal} onClose={() => setShowProfileModal(false)} />
      <LoginModal 
        isOpen={showLoginModal} 
        onClose={() => setShowLoginModal(false)} 
        onRegisterClick={() => setShowRegisterModal(true)}
      />
      <RegisterModal 
        isOpen={showRegisterModal} 
        onClose={() => setShowRegisterModal(false)}
        onLoginClick={() => setShowLoginModal(true)}
      />
    </>
  );
}