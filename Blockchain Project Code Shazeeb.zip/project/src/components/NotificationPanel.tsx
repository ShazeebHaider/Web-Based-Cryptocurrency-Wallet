import React from 'react';
import { X, Bell } from 'lucide-react';
import { useNotifications } from '../context/NotificationContext';

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function NotificationPanel({ isOpen, onClose }: NotificationPanelProps) {
  const { notifications, markAsRead, clearAll } = useNotifications();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-80 bg-white dark:bg-gray-800 shadow-xl z-50 transform transition-transform duration-300">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Bell className="h-5 w-5 text-gray-600 dark:text-gray-400" />
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Notifications</h2>
        </div>
        <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
          <X size={20} />
        </button>
      </div>

      <div className="p-4">
        <div className="flex justify-between items-center mb-4">
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {notifications.length} Notifications
          </span>
          <button
            onClick={clearAll}
            className="text-sm text-indigo-600 hover:text-indigo-500 dark:text-indigo-400"
          >
            Clear All
          </button>
        </div>

        <div className="space-y-4">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`p-3 rounded-lg ${
                notification.read
                  ? 'bg-gray-50 dark:bg-gray-700'
                  : 'bg-indigo-50 dark:bg-indigo-900'
              }`}
              onClick={() => markAsRead(notification.id)}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {notification.message}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    {notification.timestamp.toLocaleTimeString()}
                  </p>
                </div>
                {!notification.read && (
                  <span className="h-2 w-2 bg-indigo-600 rounded-full"></span>
                )}
              </div>
            </div>
          ))}

          {notifications.length === 0 && (
            <p className="text-center text-gray-500 dark:text-gray-400">
              No notifications
            </p>
          )}
        </div>
      </div>
    </div>
  );
}