import React from 'react';
import { Menu, X, Home, Wallet, History, Shield, BookOpen, Settings, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
  onNavigate: (page: string) => void;
  currentPage: string;
}

export default function Sidebar({ isOpen, toggleSidebar, onNavigate, currentPage }: SidebarProps) {
  const { logout } = useAuth();

  const menuItems = [
    { icon: Home, label: 'Dashboard', id: 'dashboard' },
    { icon: Wallet, label: 'My Wallet', id: 'wallet' },
    { icon: History, label: 'History', id: 'history' },
    { icon: Shield, label: 'Security', id: 'security' },
    { icon: BookOpen, label: 'Guide', id: 'guide' },
    { icon: Settings, label: 'Settings', id: 'settings' },
  ];

  return (
    <>
      <button
        onClick={toggleSidebar}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 rounded-lg bg-indigo-600 text-white"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      <div
        className={`fixed top-0 left-0 h-full bg-white dark:bg-gray-900 shadow-2xl transition-transform duration-300 transform z-40 
          ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 w-64`}
      >
        <div className="flex flex-col h-full">
          <div className="p-5">
            <h2 className="text-2xl font-bold text-indigo-600">CryptoVault</h2>
          </div>

          <nav className="flex-1 px-3 space-y-1">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  if (window.innerWidth < 1024) {
                    toggleSidebar();
                  }
                }}
                className={`flex items-center w-full px-4 py-3 rounded-lg transition-colors ${
                  currentPage === item.id
                    ? 'bg-indigo-50 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400'
                    : 'text-gray-700 dark:text-gray-200 hover:bg-indigo-50 dark:hover:bg-indigo-900'
                }`}
              >
                <item.icon className="h-5 w-5 mr-3" />
                {item.label}
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-gray-200 dark:border-gray-700">
            <button 
              onClick={logout}
              className="flex items-center w-full px-4 py-3 text-gray-700 dark:text-gray-200 rounded-lg hover:bg-red-50 dark:hover:bg-red-900 transition-colors"
            >
              <LogOut className="h-5 w-5 mr-3" />
              Logout
            </button>
          </div>
        </div>
      </div>
    </>
  );
}