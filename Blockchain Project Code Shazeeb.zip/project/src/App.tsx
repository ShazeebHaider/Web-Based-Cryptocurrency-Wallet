import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './pages/Dashboard';
import Wallet from './pages/Wallet';
import History from './pages/History';
import Guide from './pages/Guide';
import { useAuth } from './context/AuthContext';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState('dashboard');

  const renderPage = () => {
    switch (currentPage) {
      case 'wallet':
        return <Wallet />;
      case 'history':
        return <History />;
      case 'guide':
        return <Guide />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar 
        isOpen={isSidebarOpen} 
        toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        onNavigate={setCurrentPage}
        currentPage={currentPage}
      />
      <Header />

      <main className="lg:pl-64 pt-16">
        {renderPage()}
      </main>
    </div>
  );
}

export default App;