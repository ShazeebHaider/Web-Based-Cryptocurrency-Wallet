import React, { createContext, useContext, useState, ReactNode } from 'react';
import { useNotifications } from './NotificationContext';

interface User {
  id: string;
  username: string;
  email: string;
  balances: {
    BTC: number;
    ETH: number;
  };
  contacts: Array<{
    name: string;
    address: string;
  }>;
  settings: {
    gasPreference: 'economic' | 'standard' | 'fast';
    notifications: boolean;
    theme: 'light' | 'dark' | 'system';
  };
}

interface AuthContextType {
  user: User | null;
  register: (email: string, username: string, password: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
  updateBalance: (currency: string, amount: number) => boolean;
  addContact: (name: string, address: string) => void;
  updateSettings: (settings: Partial<User['settings']>) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const users: User[] = [];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const { addNotification } = useNotifications();

  const register = async (email: string, username: string, password: string) => {
    const existingUser = users.find(u => u.email === email);
    if (existingUser) {
      throw new Error('User already exists');
    }

    const newUser: User = {
      id: (users.length + 1).toString(),
      username,
      email,
      balances: {
        BTC: 1.5,
        ETH: 5.0,
      },
      contacts: [],
      settings: {
        gasPreference: 'standard',
        notifications: true,
        theme: 'system',
      },
    };
    
    users.push(newUser);
    addNotification('system', 'Account created successfully! Please log in.');
  };

  const login = async (email: string, password: string) => {
    const foundUser = users.find(u => u.email === email);
    if (!foundUser) {
      throw new Error('Invalid credentials');
    }
    setUser(foundUser);
    addNotification('system', 'Welcome back!');
  };

  const logout = () => {
    setUser(null);
    addNotification('system', 'Logged out successfully');
  };

  const updateProfile = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      const userIndex = users.findIndex(u => u.id === user.id);
      if (userIndex !== -1) {
        users[userIndex] = updatedUser;
        setUser(updatedUser);
        addNotification('system', 'Profile updated successfully');
      }
    }
  };

  const updateBalance = (currency: keyof User['balances'], amount: number): boolean => {
    if (!user || user.balances[currency] < amount) {
      return false;
    }

    const updatedUser = {
      ...user,
      balances: {
        ...user.balances,
        [currency]: user.balances[currency] - amount,
      },
    };

    const userIndex = users.findIndex(u => u.id === user.id);
    if (userIndex !== -1) {
      users[userIndex] = updatedUser;
      setUser(updatedUser);
      addNotification('transaction', `Sent ${amount} ${currency}`);
    }
    return true;
  };

  const addContact = (name: string, address: string) => {
    if (user) {
      const updatedUser = {
        ...user,
        contacts: [...user.contacts, { name, address }],
      };
      const userIndex = users.findIndex(u => u.id === user.id);
      if (userIndex !== -1) {
        users[userIndex] = updatedUser;
        setUser(updatedUser);
        addNotification('system', `Contact ${name} added successfully`);
      }
    }
  };

  const updateSettings = (settings: Partial<User['settings']>) => {
    if (user) {
      const updatedUser = {
        ...user,
        settings: { ...user.settings, ...settings },
      };
      const userIndex = users.findIndex(u => u.id === user.id);
      if (userIndex !== -1) {
        users[userIndex] = updatedUser;
        setUser(updatedUser);
        addNotification('system', 'Settings updated successfully');
      }
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      register,
      login,
      logout,
      updateProfile,
      updateBalance,
      addContact,
      updateSettings,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}